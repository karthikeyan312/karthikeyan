package assistedlesson1;

public class assistedmodifier {

}
