package section1;

public class methods {

		  public int addNumbers(int x, int y) {
		    int sum = x + y;
		    return sum;
		  }
		  public static void main(String[] args) {
		    int num1 = 45;
		    int num2 = 20;
		    methods obj = new methods();
		    int result = obj.addNumbers(num1, num2);
		    System.out.println("Sum is: " + result);
		  }
		}

