package section5;

public class thread {
	
	 	public void run()
	 	{
	  		System.out.println("concurrent thread started running..");
	}
	 	public static void main( String args[] )
	 	{
	  		thread mt = new  thread();
	  		mt.start();
	 	}
		private void start() {
			// TODO Auto-generated method stub
			System.out.println("thread loading..");
		}
	}
